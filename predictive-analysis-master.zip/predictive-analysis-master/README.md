
There are three files that perform the task: extarct_relevant_trproductid.py, generateMetricsData.py, and getTrproductID.py. We need to obtain the TR Product ID to complete the task. 
The following flow should be followed once we receive the TR Product ID from the customer:

Retrieve Subscriptions: Retrieve all subscriptions authorized for a particular user, using the TR Product ID as an additional parameter.
Store TR Product IDs: Store all TR Product IDs in a file (currently hardcoded to detail.txt).
Filter TR Product IDs: Filter out the required TR Product IDs provided by the user by running the command:

python extarct_relevant_trproductid.py
The output is written to filtered_output.txt (currently hardcoded value).
Generate Metrics Data: Finally, change the output file generated from step 3 (filtered_output.txt) to detail.txt and run the following command to generate the final CSV file:

python generateMetricsData.py >> <filename.csv>
This flow ensures that the TR Product ID is correctly retrieved, filtered, and used to generate the necessary metrics data.

Please connect or message a0a0lhe@walmart.com for any further queries
