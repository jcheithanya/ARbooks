# Define the TRProduct IDs to match
tr_product_ids = {"126", "1514", "1467", "2699", "1434"}

# Open the input file and output file
with open('details.txt', 'r') as infile:
    with open('filtered_output.txt', 'w') as outfile:
        # Iterate through each line in the input file
        for line in infile:
            # Split the line by '|' and strip whitespace
            fields = [field.strip() for field in line.split('|')]
            # Check if the fifth field (trProductId) is in the set of TRProduct IDs
            if fields[4] in tr_product_ids:
                # Write the original line to the output file
                outfile.write(line)

print("Filtered records written to filtered_output.txt.")

