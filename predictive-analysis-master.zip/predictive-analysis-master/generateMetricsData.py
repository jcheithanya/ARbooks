#######################################################################################################################
# Programm Name                   :  generateMetricsData.py                                                           #
#                                                                                                                     #
# Author                          :  Anand Agrawal(a0a0lhe)                                                           #
#                                                                                                                     #
# Details                         :  Program will generaate a outputfile through a redirect process, hence file name  #
#                                    needs to be provided at runtime below is the usages                              #
#                                    python generateMetricsData.py >> <outputfilename.csv>                            # 
#                                    The output file will contain all defined metrics and its analysis on hourly or   #
#                                    daily basis depedning on typr of metrics                                         #
#                                                                                                                     #
# Inputs                          :  file will take details.txt as Input parameter which can be generated             #
#                                    python getSubscription.py                                                        #
#                                                                                                                     #
# Output                          :  Output filename will be passed in runtime                                        # 
#                                                                                                                     #
# Function                        :  Function apart from Main are used which are listed as                            #
#                                    get_day_of_week(date) - Function to get the day of the week                      #
#                                    read_subscriptions(file_path) - Read subscription details from a file            #
#                                    get_database_vcores(sql_client, resource_group, sql_server_name, database_name): #
#                                         - Function to get vCores of the database                                    #
#                                    get_database_size(sql_client, resource_group, sql_server_name, database_name):   #
#                                         - Function to get the current size of the database                          #
#                                    query_metrics(monitor_client, metric_name, resource_uri, start, end)             #
#                                         - Function to Query Metrics                                                 #
#                                    process_metrics(metrics_data, min_threshold=80, max_threshold=100)               #
#                                         - Function to Compute the Metrics                                           #
#                                    combine_metrics(monitor_client, metric_name, resource_uri, time_segments)        #
#                                         - Function to Combine results for all time segments                         #
#                                    disk_size_analysis(monitor_client,resource_uri,disk_capacity_gb,time_segments)   #
#                                         - Function to analysi disk size                                             #
#                                    process_subscriptions(subscriptions)                                             #
#                                         - Main function to process subscriptions and print the output               # 
#                                                                                                                     #
#                                                                                                                     #
#                                                                                                                     #
#######################################################################################################################
#Change History:                                                                                                      #
#                                                                                                                     #
#                                                                                                                     #
#                                                                                                                     #
#                                                                                                                     #
#######################################################################################################################
from azure.identity import DefaultAzureCredential
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.sql import SqlManagementClient
from datetime import datetime
import datetime

# Function to get the day of the week
def get_day_of_week(date):
    if isinstance(date, str):
        date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
    return date.strftime('%a')

# Read subscription details from a file
def read_subscriptions(file_path):
    subscriptions = []
    with open(file_path, 'r') as file:
        header = file.readline().strip()
        for line in file:
            values = line.strip().split('|')
            if len(values) == 5:
                subscription = {
                    'subscription_id': values[0].strip(),
                    'resource_group': values[1].strip(),
                    'sql_server_name': values[2].strip(),
                    'database_name': values[3].strip(),
                    'tr_product_id': values[4].strip(),
                }
                subscriptions.append(subscription)
            else:
                print("Warning: Skipped line due to header mismatch: ", line.strip())
    return subscriptions

# Function to get vCores for the database
def get_database_vcores(sql_client, resource_group, sql_server_name, database_name):
    try:
        database = sql_client.databases.get(resource_group, sql_server_name, database_name)
        return database.sku.capacity  # This returns the number of vCores
    except Exception as e:
        print(f"Error fetching database information: {e}")
        return None


# Function to get the current size of the database
def get_database_size(sql_client, resource_group, sql_server_name, database_name):
    try:
        database = sql_client.databases.get(resource_group, sql_server_name, database_name)
        current_size_gb = database.max_size_bytes / (1024 ** 3)  # Convert bytes to GB
        return current_size_gb
    except Exception as e:
        print(f"Error fetching database size: {e}")
        return None

# Set up your parameters
subscriptions = read_subscriptions('details.txt.rap')

# Create a credential object
credential = DefaultAzureCredential()

# Function to query metrics
def query_metrics(monitor_client, metric_name, resource_uri, start, end):
    try:
        timespan = f"{start}/{end}"
        metrics_data = monitor_client.metrics.list(
            resource_uri=resource_uri,
            timespan=timespan,
            interval='PT1H',  # Hourly aggregation
            metricnames=metric_name,
            aggregation='Average,Maximum,Minimum'
        )
        return metrics_data
    except Exception as e:
        print(f"Error fetching metric '{metric_name}': {e}")
        return None


#Function to Compute the Metrics
def process_metrics(metrics_data, min_threshold=80, max_threshold=100):
    total_average = 0
    total_count = 0
    max_utilization = float('-inf')
    min_utilization = float('inf')
    total_duration_within_threshold = 0
    count_within_threshold = 0
    peak_timestamps = []
    was_in_threshold = False
    previous_time_stamp = None
    previous_was_in_threshold = False

    for item in metrics_data.value:
        for time_series in item.timeseries:
            for data_point in time_series.data:
                # Check if average is valid (not None)
                if data_point.average is not None:
                    total_average += data_point.average
                    total_count += 1
                
                # Update max and min utilization if valid
                if data_point.maximum is not None:
                    max_utilization = max(max_utilization, data_point.maximum)
                if data_point.minimum is not None:
                    min_utilization = min(min_utilization, data_point.minimum)

                # Check if we are within the defined thresholds
                if data_point.maximum is not None and min_threshold <= data_point.maximum <= max_threshold:
                    count_within_threshold += 1  # Increment the threshold counter

                    if not was_in_threshold:
                        peak_timestamps.append(data_point.time_stamp)
                    was_in_threshold = True

                    if previous_time_stamp is not None and previous_was_in_threshold:
                        # Calculate duration only if we were within the threshold previously
                        duration_at_threshold = (data_point.time_stamp - previous_time_stamp).total_seconds()
                        total_duration_within_threshold += duration_at_threshold

                    previous_time_stamp = data_point.time_stamp
                else:
                    was_in_threshold = False
                    previous_time_stamp = data_point.time_stamp if previous_time_stamp is None else previous_time_stamp

                previous_was_in_threshold = was_in_threshold  # Update previous threshold state

    overall_average = total_average / total_count if total_count > 0 else 0
    return overall_average, max_utilization, min_utilization, count_within_threshold, total_duration_within_threshold, peak_timestamps


# Combine results for all time segments
def combine_metrics(monitor_client, metric_name, resource_uri, time_segments):
    combined_metrics = None
    for start_days, end_days in time_segments:
        start = datetime.datetime.utcnow() - datetime.timedelta(days=start_days)
        end = datetime.datetime.utcnow() - datetime.timedelta(days=end_days)
        metrics_data = query_metrics(monitor_client, metric_name, resource_uri, start, end)

        if combined_metrics is None:
            combined_metrics = metrics_data
        else:
            combined_metrics.value.extend(metrics_data.value)

    return combined_metrics

#Function to analysi disk size
def disk_size_analysis(monitor_client, resource_uri, disk_capacity_gb, time_segments):
    # Combine metrics for the disk
    disk_metrics = combine_metrics(monitor_client, 'storage', resource_uri, time_segments)

    if not disk_metrics or not disk_metrics.value:
        print("No disk size metrics found.")
        return

    daily_sizes = {}

    for item in disk_metrics.value:
        for time_series in item.timeseries:
            for data in time_series.data:
                # Check if data.average is valid
                if data.average is not None:
                    timestamp = data.time_stamp.date()  # Use only the date
                    size_gb = data.average / (1024 ** 3)  # Convert bytes to GB
                    # Update max size for the day
                    daily_sizes[timestamp] = max(daily_sizes.get(timestamp, 0), size_gb)

    previous_size = None
    negative_changes = []
    trend_increases = []
    total_increase = 0
    total_decrease = 0

    # Analyze daily size changes
    for day, size in sorted(daily_sizes.items()):
        if previous_size is not None:
            change = size - previous_size
            if change > 0:
                trend_increases.append((day, change))
                total_increase += change  # Sum of all increases
            elif change < 0:
                negative_changes.append((day, change))
                total_decrease += change  # Sum of all decreases

        previous_size = size

    # Reporting results
    return {
        'negative_changes': negative_changes,
        'trend_increases': trend_increases,
        'starting_size': daily_sizes.get(sorted(daily_sizes.keys())[0], 0),
        'current_size': previous_size,
        'total_increase': total_increase,
        'total_decrease': total_decrease
    }

# Create a SQL Management Client
def create_sql_client(subscription_id):
        return SqlManagementClient(credential, subscription_id)

# Main function to process subscriptions
def process_subscriptions(subscriptions):
    # Print the results
    print("Details |||| CPU Utilization ||||||| Memory Utilization |||||| I/O Utilization |||||| Worker Thread Utilization |||||| Log Utilization |||||| Disk Space Utilization |||||| Session")
    print("Subscription ID | Resource Group | SQL Server Name | Database Name | Number of cores |"
      "CPU Max | CPU Average | CPU Min | Count of CPU threshold crossings | "
      "CPU Total duration (seconds) | CPU Peak Timing | "
      "Memory Max | Memory Average | Memory Min | Count of Memory threshold crossings | "
      "Memory Total duration (seconds) | Memory Peak Timing | "
      "I/O Max | I/O Average | I/O Min | Count of I/O threshold crossings | "
      "I/O Total duration (seconds) | I/O Peak Timing | "
      "Worker Thread Max | Worker Thread Average | Worker Thread Min | Count of Worker Thread threshold crossings | "
      "Worker Thread Total duration (seconds) | Worker Thread Peak Timing | "
      "Log Max | Log Average | Log Min | Count of Log threshold crossings | "
      "Log Total duration (seconds) | Log Peak Timing | Total Disk Size Allocated |"  
      "D-90 Size (GB) | D-0 Size (GB) | Size Difference (GB) | Increase Count with Size| Decrease Count With Size | Daily Changes | Sesson Percent Max | Session Percent Average | Session Percent Min | Count of Session Percent Threshold Crossing | Session Count Total Duration (seconds) | Session Percent Peak Timings  ")


    for subscription in subscriptions:
        subscription_id = subscription['subscription_id'].strip()
        resource_group = subscription['resource_group'].strip()
        sql_server_name = subscription['sql_server_name'].strip()
        database_name = subscription['database_name'].strip()

        # Create a monitor client
        monitor_client = MonitorManagementClient(credential, subscription_id)

        # Define the time segments for the last 90 days
        time_segments = [(90, 60), (60, 30), (30, 0)]  # Segments for the last 90 days
        resource_uri = f"/subscriptions/{subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.Sql/servers/{sql_server_name}/databases/{database_name}"

        # Query and combine relevant metrics
        cpu_metrics = combine_metrics(monitor_client, 'cpu_percent', resource_uri, time_segments)
        #cpu_metrics = combine_metrics(monitor_client, 'sql_instance_cpu_percent', resource_uri, time_segments)
        memory_metrics = combine_metrics(monitor_client, 'sqlserver_process_memory_percent', resource_uri, time_segments)
        io_metrics = combine_metrics(monitor_client, 'physical_data_read_percent', resource_uri, time_segments)
        log_metrics = combine_metrics(monitor_client, 'log_write_percent', resource_uri, time_segments)
        worker_thread_metrics = combine_metrics(monitor_client, 'workers_percent', resource_uri, time_segments)
        session_percent_metrics = combine_metrics(monitor_client, 'sessions_percent', resource_uri, time_segments)



        #####For Static Parameters
        # Create the SQL Management Client
        sql_client = create_sql_client(subscription_id)
        vcores = get_database_vcores(sql_client, resource_group, sql_server_name , database_name)
        total_disk_size = get_database_size(sql_client, resource_group, sql_server_name , database_name)

        # Process the combined metrics with threshold parameters
        cpu_avg, cpu_max, cpu_min, cpu_count, cpu_total_duration, cpu_peak_times = process_metrics(cpu_metrics)
        memory_avg, memory_max, memory_min, memory_count, memory_total_duration, memory_peak_times = process_metrics(memory_metrics)
        io_avg, io_max, io_min, io_count, io_total_duration, io_peak_times = process_metrics(io_metrics)
        log_avg, log_max, log_min, log_count, log_total_duration, log_peak_times = process_metrics(log_metrics)
        worker_thread_avg, worker_thread_max, worker_thread_min, worker_thread_count, worker_thread_total_duration, worker_thread_peak_times = process_metrics(worker_thread_metrics)
        session_percnt_avg, session_percnt_max, session_percnt_min, session_percnt_count, session_percnt_total_duration, session_percnt_peak_times = process_metrics(session_percent_metrics)

        # Perform disk size analysis
        disk_capacity_gb = 100  # Set your disk capacity here in GB
        disk_analysis = disk_size_analysis(monitor_client, resource_uri, disk_capacity_gb, time_segments)


        # Prepare the final output line

        output_line = (
            f"{subscription_id} | {resource_group} | {sql_server_name} | {database_name} | {vcores} | "
            f"{cpu_max:.2f} | {cpu_avg:.2f} | {cpu_min:.2f} | {cpu_count} | {cpu_total_duration:.0f} | "
            f"\"{'~ '.join(str(time) for time in cpu_peak_times)}\" | "
            f"{memory_max:.2f} | {memory_avg:.2f} | {memory_min:.2f} | {memory_count} | "
            f"{memory_total_duration:.0f} | \"{'~ '.join(str(time) for time in memory_peak_times)}\" | "
            f"{io_max:.2f} | {io_avg:.2f} | {io_min:.2f} | {io_count} | {io_total_duration:.0f} | "
            f"\"{'~ '.join(str(time) for time in io_peak_times)}\" | "
            f"{worker_thread_max:.2f} | {worker_thread_avg:.2f} | {worker_thread_min:.2f} | "
            f"{worker_thread_count} | {worker_thread_total_duration:.0f} | "
            f"\"{'~ '.join(str(time) for time in worker_thread_peak_times)}\" | "
            f"{log_max:.2f} | {log_avg:.2f} | {log_min:.2f} | {log_count} | "
            f"{log_total_duration:.0f} | \"{'~ '.join(str(time) for time in log_peak_times)}\" | {total_disk_size} |"
            f"{disk_analysis['starting_size']:.2f} | {disk_analysis['current_size']:.2f} | "
            f"{disk_analysis['current_size'] - disk_analysis['starting_size']:.2f} | "
            f"{len(disk_analysis['trend_increases'])} (Total Increase: {disk_analysis['total_increase']:.2f} GB) | "
            f"{len(disk_analysis['negative_changes'])} (Total Decrease: {-disk_analysis['total_decrease']:.2f} GB) | "  # Added negative sign here
            f"{'~ '.join(f'{get_day_of_week(day)} {day}: {size:.2f}' for day, size in disk_analysis['trend_increases'])} "  # Keep this as is
            f"{'~ '.join(f'{get_day_of_week(day)} {day}: {size:.2f}' for day, size in disk_analysis['negative_changes'])}i |"
            f"{session_percnt_max:.2f} | {session_percnt_avg:.2f} | {session_percnt_min:.2f} | "
            f"{session_percnt_count} | {session_percnt_total_duration:.0f} | "
            f"\"{'~ '.join(str(time) for time in session_percnt_peak_times)}\"  "
        )

        print(output_line)

# Execute the main process
process_subscriptions(subscriptions)
