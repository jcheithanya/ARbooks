#############################################################################################################################
# Program Name                              : getTrproductID.py                                                             #
# Description                               : This program extract the data based on subscription for the given user id     #
# Developer                                 : Anand Agrawal                                                                 #
# Input  		                    : subscription.txt ( list of subscription in it )                               #
# Output  		                    : Each subscription is generated a file with subscription name and all execution# 
#                                             is done is parallel and final output is detail.txt file                       #
# Function                                  : get_databases(subscription_name) fetch details of database name for each sub  #
#                                             write_output(subscription_name, output) final output to the file              #
#                                                                                                                           #
#############################################################################################################################
# Modification History :                                                                                                    #
#                                                                                                                           #
#############################################################################################################################
import os
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from azure.identity import DefaultAzureCredential
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.subscription import SubscriptionClient

# Function to retrieve databases for a given subscription
def get_databases(subscription_name):
    credential = DefaultAzureCredential()
    subscription_client = SubscriptionClient(credential)

    # Find the subscription ID by name
    subscription_id = None
    for subscription in subscription_client.subscriptions.list():
        if subscription.display_name == subscription_name:
            subscription_id = subscription.subscription_id
            break

    if subscription_id is None:
        return f"Subscription not found: {subscription_name}\n"

    sql_management_client = SqlManagementClient(credential, subscription_id)
    resource_group_info = []

    # List of databases to exclude
    databases_to_exclude = ['master']  # add databases which need not be considered

    # Get the list of SQL servers in the subscription
    servers = sql_management_client.servers.list()

    # Iterate through servers and their databases
    for server in servers:
        resource_group = server.id.split('/')[4]  # Extract resource group from the server ID
        sql_server_name = server.name

        # Get databases for the current server
        databases = sql_management_client.databases.list_by_server(resource_group, sql_server_name)

        # Collect details for each database, excluding specified ones
        for database in databases:
            if database.name not in databases_to_exclude:
                
                # Check if tags are available and extract trProductId
                if database.tags is not None:
                     tr_product_id = database.tags.get('trproductid', 'N/A')  # Default to 'N/A' if tag is not found
                else:
                     tr_product_id = 'N/A'  # No tags available
                resource_group_info.append(
                    f"{subscription_id} | {resource_group} | {sql_server_name} | {database.name} | {tr_product_id}\n"
                )

    return ''.join(resource_group_info)

# Function to write the output to a file
def write_output(subscription_name, output):
    output_file_name = f"{subscription_name.replace(' ', '_')}_output.txt"
    with open(output_file_name, 'w') as output_file:
        # Write header
        output_file.write("subscription_id | resource_group | sql_server_name | database_name | trProductId\n")
        output_file.write(output)  # Write the database details
    print(f"Wrote output to file: {output_file_name}")
    return output_file_name  # Return the name of the output file

# Main execution
if __name__ == "__main__":
    # Read subscription names from a file, ignoring comments
    with open('subscription.txt', 'r') as file:
        subscription_names = [
            line.strip() for line in file.readlines() if line.strip() and not line.startswith('#')
        ]

    # Print the valid subscription names
    print("Valid Subscription Names:")
    for name in subscription_names:
        print(name)

    # Use ThreadPoolExecutor to run the tasks in parallel
    with ThreadPoolExecutor() as executor:
        print("Value of ThreadPoolExecutor:", executor)

        # Dictionary to keep track of futures for database retrieval
        futures = {executor.submit(get_databases, name): name for name in subscription_names}

        # Now handle file writing in parallel as well
        write_futures = {}
        for future in as_completed(futures):
            subscription_name = futures[future]
            output = future.result()  # This will block until the future is done
            print(f"Finished processing subscription: {subscription_name}")
            
            # Submit the file writing task
            write_future = executor.submit(write_output, subscription_name, output)
            write_futures[write_future] = subscription_name

        # Combine all output files into one
        combined_file_name = f"details.txt"
        with open(combined_file_name, 'w') as combined_file:
            # Write the header
            combined_file.write("subscription_id | resource_group | sql_server_name | database_name | trProductId\n")
            for write_future in as_completed(write_futures):
                subscription_name = write_futures[write_future]
                output_file_name = write_future.result()  # This will give the name of the written file
                with open(output_file_name, 'r') as f:
                    combined_file.write(f.read())  # Append the contents of each file
                # Remove the individual output file after reading
                ##os.remove(output_file_name)
                ##print(f"Removed file: {output_file_name}")

    print(f"All outputs written to {combined_file_name}.")

